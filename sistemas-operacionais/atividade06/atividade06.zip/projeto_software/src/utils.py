# Arquivo utils.py
