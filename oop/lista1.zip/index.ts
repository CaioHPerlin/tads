class Autor {
  nome: string;
  nacionalidade: string;
  dataNascimento: Date;

  constructor(nome: string, nacionalidade: string, dataNascimento: Date) {
    this.nome = nome;
    this.nacionalidade = nacionalidade;
    this.dataNascimento = dataNascimento;
  }
}

class Livro {
  titulo: string;
  anoDePublicacao: number;

  constructor(titulo: string, anoDePublicacao: number) {
    this.titulo = titulo;
    this.anoDePublicacao = anoDePublicacao;
  }
}

class Usuario {
  nome: string;
  idade: number;

  constructor(nome: string, idade: number) {
    this.nome = nome;
    this.idade = idade;
  }
}

const autor = new Autor(
  "Machado de Assis",
  "Brasileiro",
  new Date("1839-06-21")
);
const livro = new Livro("Dom Casmurro", 1899);
const usuario = new Usuario("João Doe", 30);

console.log(`\nAutor: ${autor.nome}`);
console.log(`- Nacionalidade: ${autor.nacionalidade}`);
console.log(
  `- Data de nascimento: ${autor.dataNascimento.toLocaleDateString()}`
);

console.log(`\nLivro: ${livro.titulo}`);
console.log(`- Ano de publicação: ${livro.anoDePublicacao}`);

console.log(`\nUsuário: ${usuario.nome}`);
console.log(`- Idade: ${usuario.idade}`);
